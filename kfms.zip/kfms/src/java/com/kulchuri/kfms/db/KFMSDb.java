package com.kulchuri.kfms.db;

import java.sql.*;

public class KFMSDb {

    private final static String USER = "root";
    private final static String PWD = "kulchuri";
    private final static String DRIVER = "com.mysql.jdbc.Driver";
    private final static String URL = "jdbc:mysql://localhost:3306/feeinfo";
    private static Connection conn = null;

    static {
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PWD);

        } catch (Exception e) {

            System.out.println("CONNECTION FAILED" + e);

        }
    }

    public static Connection getCrudDb() {

        return conn;

    }

    public static void main(String[] args) {
        System.out.println(getCrudDb());
    }

}
