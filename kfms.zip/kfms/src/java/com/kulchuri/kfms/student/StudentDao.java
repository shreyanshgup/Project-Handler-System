package com.kulchuri.kfms.student;

import com.kulchuri.kfms.db.KFMSDb;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;

public class StudentDao {

    private Connection conn = null;
    private PreparedStatement ps = null;

    private ResultSet rs = null;

    public StudentDao() {
    }

    public int addStudent(StudentDto dto, InputStream photo) {
        int studentId = 0;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();

        }
        try {
            String query = "insert into student(name,bid,email,mno,address,photo,dob) values (?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, dto.getName());
            ps.setInt(2, dto.getBid());
            ps.setString(3, dto.getEmail());
            ps.setString(4, dto.getMno());
            ps.setString(5, dto.getAddress());
            ps.setBlob(6, photo);
            if(ps!=null)
            {
            ps.setString(7,dto.getDob());
            }
            if (ps.executeUpdate() > 0) {
                ps = conn.prepareStatement("SELECT max(sid) as sid FROM student");
                rs = ps.executeQuery();
                if (rs.next()) {
                    studentId = rs.getInt("sid");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at addStudent():" + e);
        } finally {
            ps = null;
            rs = null;
            return studentId;

        }
    }

    public ResultSet getAllStudents() {
        ResultSet rs = null;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            rs = conn.prepareStatement("SELECT sub.name as sname, b.timing,b.date, s.* FROM student s,batch b,subject sub where s.bid=b.bid and sub.sid=b.sid").executeQuery();
        } catch (Exception e) {
            System.out.println("Exception at getAllStudents():" + e);
        } finally {
            return rs;
        }
    }

    public ResultSet getAllStudentsBySubject(int sid) {
        ResultSet rs = null;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            rs = conn.prepareStatement("SELECT sub.name as sname, b.timing,b.date, s.* FROM student s,batch b,subject sub where s.bid=b.bid and sub.sid=b.sid and sub.sid=" + sid).executeQuery();
        } catch (Exception e) {
            System.out.println("Exception at getAllStudentsBySubject():" + e);
        } finally {
            return rs;
        }
    }

public void deleteStudent(int sid) {

        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            String query = "delete from student where sid=?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, sid);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception at deleteStudent()" + e);

        } finally {
            ps = null;
            conn = null;

        }

    }




}
