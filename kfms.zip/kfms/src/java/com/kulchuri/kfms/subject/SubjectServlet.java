package com.kulchuri.kfms.subject;

//import com.kulchuri.kfms.student.StudentDao;
import com.kulchuri.kfms.utility.KFMSDate;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SubjectServlet", urlPatterns = {"/SubjectServlet"})
public class SubjectServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String name = req.getParameter("name");
        String f = req.getParameter("fees");
        String date = KFMSDate.getCurrentDate();
        float fees = Float.parseFloat(f);
        SubjectDto dto = new SubjectDto();
        dto.setName(name);
        dto.setFees(fees);
        dto.setDate(date);
        SubjectDao dao = new SubjectDao();
        if (dao.addSubject(dto)) {
            resp.sendRedirect("viewAllSubjects.jsp");
        } else {
            resp.sendRedirect("addSubject.jsp");
        }
    }


protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        //    super.doGet(req, resp); //To change body of generated methods, choose Tools | Templates.
        String sno = req.getParameter("sid");
        int sid = Integer.parseInt(sno);
        SubjectDao dao = new SubjectDao();
        dao.deleteSubject(sid);
        resp.sendRedirect("viewAllSubjects.jsp");

    }

}






