package com.kulchuri.kfms.subject;

import com.kulchuri.kfms.db.KFMSDb;
import java.sql.*;
import java.util.ArrayList;

public class SubjectDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public SubjectDao() {

    }

    public boolean addSubject(SubjectDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();

        }
        try {

            String query = "insert into subject(name,fees,date) values (?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setString(1, dto.getName());
            ps.setFloat(2, dto.getFees());
            ps.setString(3, dto.getDate());

            if (ps.executeUpdate() > 0) {
                flag = true;

            }

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at addSubject" + e);

        } finally {
            conn = null;
            ps = null;
            return flag;

        }

    }

    public ArrayList<SubjectDto> getAllSubjects() {
        ArrayList<SubjectDto> al = new ArrayList<>();
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            ps = conn.prepareStatement("select *from subject");
            rs = ps.executeQuery();
            SubjectDto dto;
            while (rs.next()) {
                dto = new SubjectDto();
                dto.setSid(rs.getInt("sid"));
                dto.setName(rs.getString("name"));
                dto.setFees(rs.getFloat("fees"));
                dto.setDate(rs.getString("date"));
                al.add(dto);
            }
        } catch (Exception e) {
            System.out.println("Exception at getAllSubjects():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }

    public boolean checkDuplicateSubject(String name) {
        boolean flag = false;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            ps = conn.prepareStatement("select name from subject where name=?");
            ps.setString(1, name);
            rs = ps.executeQuery();
            if (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            System.out.println("Exception at checkDuplicateSubject():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }

    public float getFeesByStudent(int studentId) {
        float fees = 0;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            ps = conn.prepareStatement("SELECT sub.fees  FROM batch b,student st, subject sub where st.bid=b.bid and "
                    + "b.sid=sub.sid and st.sid=?");
            ps.setInt(1, studentId);
            rs = ps.executeQuery();
            if (rs.next()) {
                fees = rs.getFloat("fees");
            }
        } catch (Exception e) {
            System.out.println("Exception at getFeesByStudent():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return fees;
        }
    }
    
    public void deleteSubject(int sid) {

        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            String query = "delete from subject where sid=?";
            ps = conn.prepareStatement(query);
            ps.setInt(1, sid);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception at deleteSubject()" + e);

        } finally {
            ps = null;
            conn = null;

        }

    }

}  
    

/*    public static void main(String[] args) {
        System.out.println(new SubjectDao().checkDuplicateSubject("Java"));
    }
}
*/