package com.kulchuri.kfms.batch;

import com.kulchuri.kfms.utility.KFMSDate;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "BatchServlet", urlPatterns = {"/BatchServlet"})
public class BatchServlet extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        
        String timing = req.getParameter("timing");
        String date = KFMSDate.getCurrentDate();
        String s = req.getParameter("sid");
        int sid = Integer.parseInt(s);
        BatchDto dto = new BatchDto();
        dto.setTiming(timing);
        dto.setSid(sid);
        dto.setDate(date);
        BatchDao dao = new BatchDao();
        if (dao.addBatch(dto)) {
            resp.sendRedirect("viewAllBatches.jsp");
        } else {
            resp.sendRedirect("addBatch.jsp");
        }
    }
    
}
