package com.kulchuri.kfms.fees;

import com.kulchuri.kfms.subject.SubjectDao;
import com.kulchuri.kfms.utility.KFMSDate;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "PayFeesServlet", urlPatterns = {"/PayFeesServlet"})
public class PayFeesServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String fee = req.getParameter("fees");
        String id = req.getParameter("sid");
        int sid = Integer.parseInt(id);
        float amount = Float.parseFloat(fee);
        FeesDao dao = new FeesDao();
        String opn = req.getParameter("opn");
        if (opn != null && opn.contains("Pay Fees")) {
            FeesDto dto = dao.getLastFees(sid);
            float balance = dto.getBalance() - amount;
            String pdate = KFMSDate.getCurrentDate();
            dto = new FeesDto();
            dto.setSid(sid);
            dto.setBalance(balance);
            dto.setAmount(amount);
            dto.setPdate(pdate);
            dao = new FeesDao();
            if (dao.addFees(dto)) {
                resp.sendRedirect("displayPayment.jsp?sid="+sid);
            } else {
                  resp.sendRedirect("payByAdmin.jsp?sid="+sid);
            }
        } else {

            float fees = new SubjectDao().getFeesByStudent(sid);
            float balance = fees - amount;
            String pdate = KFMSDate.getCurrentDate();
            FeesDto dto = new FeesDto();
            dto.setSid(sid);
            dto.setBalance(balance);
            dto.setAmount(amount);
            dto.setPdate(pdate);
            dao = new FeesDao();
            if (dao.addFees(dto)) {
                resp.sendRedirect("displayPayment.jsp?sid="+sid);
            } else {
                 resp.sendRedirect("payByAdmin.jsp?sid="+sid);
            }
        }
    }
}
