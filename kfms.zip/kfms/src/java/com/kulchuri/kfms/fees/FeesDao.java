package com.kulchuri.kfms.fees;

import com.kulchuri.kfms.db.KFMSDb;
import java.sql.*;
import java.util.ArrayList;

public class FeesDao {

    private Connection conn = null;
    private PreparedStatement ps = null;
    private ResultSet rs = null;

    public FeesDao() {
    }

    public boolean addFees(FeesDto dto) {
        boolean flag = false;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();

        }
        try {
            String query = "insert into fees(sid,amount,balance,pdate) values(?,?,?,?)";
            ps = conn.prepareStatement(query);
            ps.setInt(1, dto.getSid());
            ps.setFloat(2, dto.getAmount());
            ps.setFloat(3, dto.getBalance());
            ps.setString(4, dto.getPdate());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at" + e);

        } finally {
            ps = null;
            conn = null;
            return flag;
        }
    }

    public ArrayList<FeesDto> getFeesByStudent(int sid) {
        ArrayList<FeesDto> al = new ArrayList<FeesDto>();
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            ps = conn.prepareStatement(" select *  from fees where sid=?");
            ps.setInt(1, sid);
            rs = ps.executeQuery();
            while (rs.next()) {
                FeesDto dto = new FeesDto();
                dto.setAmount(rs.getFloat("amount"));
                dto.setBalance(rs.getFloat("balance"));
                dto.setPdate(rs.getString("pdate"));
                al.add(dto);
            }
        } catch (Exception e) {
            System.out.println("Exception at getFeesByStudent()" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            rs = null;
            ps = null;
            conn = null;
            return al;
        }
    }
    public FeesDto getLastFees(int sid) {
       FeesDto dto=null;
        if (conn == null) {
            conn = KFMSDb.getCrudDb();
        }
        try {
            ps = conn.prepareStatement("SELECT * FROM fees where fid=(SELECT max(fid) as fid FROM fees where sid=?)");
            ps.setInt(1, sid);
            rs = ps.executeQuery();
            if (rs.next()) {
               dto = new FeesDto();
                dto.setAmount(rs.getFloat("amount"));
               
                dto.setBalance(rs.getFloat("balance"));
                dto.setPdate(rs.getString("pdate"));
            }
        } catch (Exception e) {
            System.out.println("Exception at getLastFees():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return dto;
        }
    }
}
