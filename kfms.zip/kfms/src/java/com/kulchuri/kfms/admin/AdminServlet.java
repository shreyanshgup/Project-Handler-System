package com.kulchuri.kfms.admin;

import com.kulchuri.kfms.utility.KFMSPassword;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class AdminServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html");
        //ye upper isliye likha h ke html file ke content show na ho sirf ek helpful message print ho
        
        try {
            String email = request.getParameter("email");
            String pwd = request.getParameter("pwd");
            String opn = request.getParameter("opn");
            HttpSession session = request.getSession();
            //session tracking code
            if (opn != null && opn.equals("Reset")) {
                new AdminDao().resetPwd((String) session.getAttribute("email"), KFMSPassword.encrypt(pwd));
                response.sendRedirect("adminHome.jsp");
                // password reset hone ke baad admin home pr he redirect kr waye
            } else {
                if (new AdminDao().adminLogin(email, KFMSPassword.encrypt(pwd))) {
                    //if m email password check krwa rhe h valid h ke  nhi
                    //     Handle Session Tracking
                //    store data into session scope
                    session.setAttribute("email", email);
                    response.sendRedirect("adminHome.jsp");
                    //email and password agar sahi h toh ye chalega or adminHome(student ,batch,subject details sab dekhega) bale page pr ayege
                } else {
                    //email password galah h to msg print krega
                    response.sendRedirect("signin.jsp?msg=Please Enter Valid Login Details");
                }
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
