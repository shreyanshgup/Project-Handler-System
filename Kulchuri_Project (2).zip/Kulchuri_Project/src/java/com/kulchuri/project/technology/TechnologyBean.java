package com.kulchuri.project.technology;

public class TechnologyBean {

    private int tid;
    private String tname;

    public TechnologyBean() {
    }

    public int getTid() {
        return tid;
    }

    public void setTid(int tid) {
        this.tid = tid;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }
    
}
