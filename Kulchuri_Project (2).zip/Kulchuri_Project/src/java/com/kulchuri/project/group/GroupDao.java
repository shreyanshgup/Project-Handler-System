package com.kulchuri.project.group;

import com.kulchuri.project.db.KulchuriDb;
import com.kulchuri.project.utility.KFMSDate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class GroupDao {
    
    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private Connection conn = null;
    
    public boolean addGroup(GroupBean bean) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            // String sql="insert into group(tid,eno1,eno2,eno3,eno4,date,ptitle) values (?,?,?,?,?,?,?)";
            ps = conn.prepareStatement("insert into group_master(tid,eno1,eno2,eno3,eno4,date,ptitle) values (?,?,?,?,?,?,?)");
            ps.setInt(1, bean.getTid());
            ps.setString(2, bean.getEno1());
            ps.setString(3, bean.getEno2());
            ps.setString(4, bean.getEno3());
            ps.setString(5, bean.getEno4());
            ps.setString(6, KFMSDate.getCurrentDate());
            ps.setString(7, bean.getPtitle());
            
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
            
        } catch (Exception e) {
            System.out.println("Exception at addGroup():" + e);
        } finally {
            ps = null;
            rs = null;
            conn = null;
            return flag;
        }
    }
    
    public boolean updateGroup(GroupBean bean) {
        boolean flag = false;
        
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            
            String sql = "update group_master set tid=?, eno1=?, eno2=?, eno3=?, eno4=?, ptitle=? where gpid=?";
            ps = conn.prepareStatement(sql);
            //   ps.setInt(1,bean.getGpid());
            ps.setInt(1, bean.getTid());
            ps.setString(2, bean.getEno1());
            ps.setString(3, bean.getEno2());
            ps.setString(4, bean.getEno3());
            ps.setString(5, bean.getEno4());
            //         ps.setString(6, KFMSDate.getCurrentDate());
            ps.setString(6, bean.getPtitle());
            ps.setInt(7, bean.getGpid());
            if (ps.executeUpdate() > 0) {
                flag = true;
            }
            
        } catch (Exception e) {
            System.out.println("Exception at updateGroup():" + e);
        } finally {
            return flag;
        }
    }
    
    public boolean deleteGroup(int gpid) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "delete from group_master where gpid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, gpid);
            ps.executeUpdate();
            
        } catch (Exception e) {
            System.out.println("Exception at addGroup():" + e);
        } finally {
            return flag;
        }
    }
    
    public GroupBean getGroup(String gpid) {
        GroupBean bean = null;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            
            String sql = "select * from group_master where gpid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(gpid));
            rs = ps.executeQuery();
            if (rs.next()) {
                bean = new GroupBean();
                // bean.setGpid(rs.getInt("gpid"));
                bean.setTid(rs.getInt("tid"));
                bean.setEno1(rs.getString("eno1"));
                bean.setEno2(rs.getString("eno2"));
                bean.setEno3(rs.getString("eno3"));
                bean.setEno4(rs.getString("eno4"));
                //bean.setDate(rs.getString("date"));
                bean.setPtitle(rs.getString("ptitle"));
                
            }
            
        } catch (Exception e) {
            System.out.println("Exception at getGroup():" + e);
        } finally {
            return bean;
        }
    }
    
    public ArrayList<GroupBean> getAllGroups() {
        ArrayList<GroupBean> al = new ArrayList<>();
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
//            GroupBean bean=new GroupBean();
            String sql = "select gm.*,t.tname,g.gname  from group_master gm,technology t,guide g where gm.tid=t.tid and g.tid=t.tid";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                GroupBean bean = new GroupBean();
                bean.setGname(rs.getString("gname"));
                bean.setGpid(rs.getInt("gpid"));
                bean.setTid(rs.getInt("tid"));
                bean.setEno1(rs.getString("eno1"));
                bean.setEno2(rs.getString("eno2"));
                bean.setEno3(rs.getString("eno3"));
                bean.setEno4(rs.getString("eno4"));
                bean.setDate(rs.getString("date"));
                bean.setPtitle(rs.getString("ptitle"));
                bean.setTname(rs.getString("tname"));
                al.add(bean);
            }
            
        } catch (Exception e) {
            System.out.println("Exception at getAllGroups():" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }
    
    ArrayList<GroupBean> getAllGroupsByTechnology(int tid) {
        ArrayList<GroupBean> al = new ArrayList<>();
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select * from group_master";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();
            
            while (rs.next()) {
                GroupBean bean = new GroupBean();
                bean.setTid(rs.getInt("tid"));
                bean.setEno1(rs.getString("eno1"));
                bean.setEno2(rs.getString("eno2"));
                bean.setEno3(rs.getString("eno3"));
                bean.setEno4(rs.getString("eno4"));
                bean.setDate(rs.getString("date"));
                bean.setPtitle(rs.getString("ptitle"));
                al.add(bean);
            }
            
        } catch (Exception e) {
            System.out.println("Exception at addGroup():" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }
    
    public boolean checkAvailibilityInGroup(String eno) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select * from group_master where eno1=?, eno2=?, eno3=?, eno4=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eno);
            ps.setString(2, eno);
            ps.setString(3, eno);
            ps.setString(4, eno);
            rs = ps.executeQuery();
            if (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            System.out.println("Exception at checkAvailibilityInGroup():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }
    
    //ajax
    public boolean checkStudentGroup(String eno) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select * from group_master where eno1=? or eno2=? or eno3=? or eno4=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eno);
            ps.setString(2, eno);
            ps.setString(3, eno);
            ps.setString(4, eno);
            
            rs = ps.executeQuery();
            if (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Exception at checkStudentGroup():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }
    public static void main(String[] args) {
        System.out.println(new GroupDao().checkStudentGroup("0103CS183D01"));
    }
    
    
    
    
    
}
