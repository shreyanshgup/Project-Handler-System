package com.kulchuri.project.student;

import com.kulchuri.project.db.KulchuriDb;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.servlet.annotation.WebServlet;
@WebServlet(urlPatterns = {"/SignOut"})
public class StudentDao {

    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private Connection conn = null;

    public StudentDao() {
    }

    public boolean addStudent(StudentBean bean) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "insert into student(eno, name, gender, branch, sem, section, mno, pwd) values (?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, bean.getEno());
            ps.setString(2, bean.getName());
            ps.setString(3, bean.getGender());
            ps.setString(4, bean.getBranch());
            ps.setString(5, bean.getSem());
            ps.setString(6, bean.getSection());
            ps.setString(7, bean.getMno());
            ps.setString(8, bean.getPwd());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            System.out.println("Exception at addStudent():" + e);
        } finally {
            ps = null;
            rs = null;
            conn = null;

            return flag;
        }

    }

    public boolean updateStudent(StudentBean bean) {
        boolean flag = false;

        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {

            String sql = "update student set  name=?, gender=?, branch=?, sem=?, section=?, mno=?, pwd=? where eno=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, bean.getName());
            ps.setString(2, bean.getGender());
            ps.setString(3, bean.getBranch());
            ps.setString(4, bean.getSem());
            ps.setString(5, bean.getSection());
            ps.setString(6, bean.getMno());
            ps.setString(7, bean.getPwd());
            ps.setString(8, bean.getEno());
            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            System.out.println("Exception at updateStudent():" + e);
        } finally {
            return flag;
        }
    }

    public boolean deleteStudent(String eno) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "delete from student where eno=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eno);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception at deleteStudent():" + e);
        } finally {
            return flag;
        }
    }

    public StudentBean getStudent(String eno) {
        StudentBean bean = null;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {

            String sql = "select * from student where eno=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eno);
            rs = ps.executeQuery();
            if (rs.next()) {
                bean = new StudentBean();
//                bean.setGpid(rs.getInt("gpid"));
                bean.setEno(rs.getString("eno"));
                bean.setName(rs.getString("name"));
                bean.setGender(rs.getString("gender"));
                bean.setBranch(rs.getString("branch"));
                bean.setSem(rs.getString("sem"));
                bean.setSection(rs.getString("section"));
                bean.setMno(rs.getString("mno"));
                bean.setPwd(rs.getString("pwd"));

            }

        } catch (Exception e) {
            System.out.println("Exception at getStudent():" + e);
        } finally {
            return bean;
        }
    }

    public ArrayList<StudentBean> getAllStudent() {
        ArrayList<StudentBean> al = new ArrayList<>();
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
//            GroupBean bean=new GroupBean();
            String sql = "select * from student";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                StudentBean bean = new StudentBean();
                bean.setEno(rs.getString("eno"));
                bean.setName(rs.getString("name"));
                bean.setMno(rs.getString("mno"));
                bean.setGender(rs.getString("gender"));
                bean.setBranch(rs.getString("branch"));
                bean.setSection(rs.getString("section"));
                bean.setSem(rs.getString("sem"));
                bean.setPwd(rs.getString("pwd"));

                al.add(bean);
            }

        } catch (Exception e) {
            System.out.println("Exception at getAllStudent():" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }

    public boolean checkAvailibilityInStudent(String eno) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select * from student where eno=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eno);
            rs = ps.executeQuery();
            if (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            System.out.println("Exception at checkAvailibilityInStudent():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }

    public boolean checkStudentEno(String eno) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select eno from student where eno=?";
            ps = conn.prepareStatement(sql);
            ps.setString(1, eno);
            rs = ps.executeQuery();
            if (rs.next()) {
                flag = true;
            }
        } catch (Exception e) {
            System.out.println("Exception at checkStudentEno():" + e);
        } finally {
            rs = null;
            ps = null;
            conn = null;
            return flag;
        }
    }
    public static void main(String[] args) {
        System.out.println(new StudentDao().checkStudentEno("9176CS17100"));
    }
}
