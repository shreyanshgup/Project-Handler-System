package com.kulchuri.project.student;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

@MultipartConfig(maxFileSize = 8887888)
@WebServlet(name = "UploadData", urlPatterns = {"/UploadData"})
public class UploadData extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try {
            FileInputStream fs = (FileInputStream) request.getPart("path").getInputStream();
            Workbook wb = Workbook.getWorkbook(fs);
            Sheet sh = wb.getSheet(0);
            int totalNoOfRows = sh.getRows();
            int totalNoOfCols = sh.getColumns();
            System.out.println("c:"+totalNoOfCols);
            System.out.println("r:"+totalNoOfRows);
            System.out.println("eno\tname\tpwd\tgender\tsection\tsem\tbranch\tmno");
            for (int row = 1; row < totalNoOfRows; row++) {
                List info = new ArrayList();
                for (int col = 0; col < totalNoOfCols; col++) {
                    if (sh.getCell(col, row).getContents().length() != 0) {
                        info.add(sh.getCell(col, row).getContents());
                    }
                }
                //create dto and dao object and call addData method of dao
                System.out.println(info.get(0) + "\t" + info.get(1) + "\t" + info.get(2) + "\t" + info.get(3) + "\t" + info.get(4)+ "\t" + info.get(5)+ "\t" + info.get(6)+ "\t" + info.get(7)+ "\t");
            StudentBean s=new StudentBean();
            s.setEno(info.get(0)+"");
            s.setName(info.get(1)+"");
            s.setPwd(info.get(2)+"");
            s.setGender(info.get(3)+"");
            s.setSection(info.get(4)+"");
            s.setSem(info.get(5)+"");
            s.setBranch(info.get(6)+"");
            s.setMno(info.get(7)+"");
//            }
            StudentDao sd= new StudentDao();
            sd.addStudent(s);
            }
            PrintWriter pd= response.getWriter();
            pd.print("Sucessfully Inserted into Database ");
            
        } catch (IOException | IndexOutOfBoundsException | ServletException | BiffException e) {
            System.out.println(e);
        }
    }
}
