/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.kulchuri.project.guide;

import com.kulchuri.project.db.KulchuriDb;
import com.kulchuri.project.group.GroupBean;
import com.kulchuri.project.group.GroupDao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

/**
 *
 * @author hp
 */
public class GuideDao {

    private PreparedStatement ps = null;
    private ResultSet rs = null;
    private Connection conn = null;

    public boolean addGuide(GuideBean bean) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "insert into guide(tid, gname, mno, email, pwd, gender) values (?,?,?,?,?,?)";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, bean.getTid());
            ps.setString(2, bean.getGname());
            ps.setString(3, bean.getMno());
            ps.setString(4, bean.getEmail());
            ps.setString(5, bean.getPwd());
            ps.setString(6, bean.getGender());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            System.out.println("Exception at addGuide():" + e);
        } finally {
            ps = null;
            rs = null;
            conn = null;

            return flag;
        }
    }

    public boolean updateGuide(GuideBean bean) {
        boolean flag = false;

        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {

            String sql = "update guide set tid=?, gname=?, mno=?, email=?, pwd=?, gender=? where gid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(7, bean.getGid());

            ps.setInt(1, bean.getTid());
            ps.setString(2, bean.getGname());
            ps.setString(3, bean.getMno());
            ps.setString(4, bean.getEmail());
            ps.setString(5, bean.getPwd());
            ps.setString(6, bean.getGender());

            if (ps.executeUpdate() > 0) {
                flag = true;
            }

        } catch (Exception e) {
            System.out.println("Exception at updateGuide():" + e);
        } finally {
            return flag;
        }
    }

    public boolean deleteGuide(int gid) {
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "delete from guide where gid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, gid);
            ps.executeUpdate();

        } catch (Exception e) {
            System.out.println("Exception at addGroup():" + e);
        } finally {
            ps = null;
            conn = null;
            return flag;
        }
    }

    public GuideBean getGuide(int gid) {
        GuideBean bean = null;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {

            String sql = "select * from guide where gid=?";
            ps = conn.prepareStatement(sql);
            ps.setInt(1, gid);
            rs = ps.executeQuery();
            if (rs.next()) {
                bean = new GuideBean();
//                bean.setGpid(rs.getInt("gpid"));
                bean.setTid(rs.getInt("tid"));
                bean.setGname(rs.getString("gname"));
                bean.setMno(rs.getString("mno"));
                bean.setEmail(rs.getString("email"));
                bean.setPwd(rs.getString("pwd"));
                bean.setGender(rs.getString("gender"));
//                bean.setPtitle(rs.getString("ptitle"));

            }

        } catch (Exception e) {
            System.out.println("Exception at getGuide():" + e);
        } finally {
            return bean;
        }
    }

    public ArrayList<GuideBean> getAllGuide() {
        ArrayList<GuideBean> al = new ArrayList<>();
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
//            GroupBean bean=new GroupBean();
            String sql = "select g.*,t.tname from guide g,technology t where t.tid=g.tid";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                GuideBean bean = new GuideBean();
                bean.setGid(rs.getInt("gid"));
                bean.setTid(rs.getInt("tid"));
                bean.setTname(rs.getString("tname"));
                bean.setGname(rs.getString("gname"));
                bean.setMno(rs.getString("mno"));
                bean.setEmail(rs.getString("email"));
                bean.setPwd(rs.getString("pwd"));
                bean.setGender(rs.getString("gender"));

                al.add(bean);
            }

        } catch (Exception e) {
            System.out.println("Exception at getAllGuide():" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            return al;
        }
    }

    ArrayList<GuideBean> getAllGuideByTechnology(int tid) {
        ArrayList<GuideBean> al = new ArrayList<>();
        boolean flag = false;
        if (conn == null) {
            conn = KulchuriDb.getCrudDb();
        }
        try {
            String sql = "select * from group";
            ps = conn.prepareStatement(sql);
            rs = ps.executeQuery();

            while (rs.next()) {
                GuideBean bean = new GuideBean();
                bean.setTid(rs.getInt("tid"));
                bean.setGname(rs.getString("gname"));
                bean.setMno(rs.getString("mno"));
                bean.setEmail(rs.getString("email"));
                bean.setGender(rs.getString("gender"));
                al.add(bean);
            }

        } catch (Exception e) {
            System.out.println("Exception at addGroup():" + e);
        } finally {
            if (al.isEmpty()) {
                al = null;
            }
            ps = null;
            rs = null;
            conn = null;
            return al;
        }
    }
}
