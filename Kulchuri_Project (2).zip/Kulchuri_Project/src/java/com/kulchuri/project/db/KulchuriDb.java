package com.kulchuri.project.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class KulchuriDb {
    private final static String USER = "root";
    private final static String PWD = "kulchuri";
    private final static String DRIVER = "com.mysql.jdbc.Driver";
    private final static String URL = "jdbc:mysql://localhost:3306/projectinfo";
    private static Connection conn = null;

    public KulchuriDb() {
    }

    static {
        try {
            Class.forName(DRIVER);
            conn = DriverManager.getConnection(URL, USER, PWD);

        } catch (Exception e) {

            System.out.println("CONNECTION FAILED" + e);

        }
    }

    public static Connection getCrudDb() {

        return conn;

    }

    public static void main(String[] args) {
        System.out.println(getCrudDb());
    }
    
}
