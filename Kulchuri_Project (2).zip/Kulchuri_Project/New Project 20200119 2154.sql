-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.13-rc-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema projectinfo
--

CREATE DATABASE IF NOT EXISTS projectinfo;
USE projectinfo;

--
-- Definition of table `admin_login`
--

DROP TABLE IF EXISTS `admin_login`;
CREATE TABLE `admin_login` (
  `aid` int(10) unsigned NOT NULL auto_increment,
  `uname` varchar(45) NOT NULL,
  `pwd` varchar(45) NOT NULL,
  PRIMARY KEY  (`aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_login`
--

/*!40000 ALTER TABLE `admin_login` DISABLE KEYS */;
INSERT INTO `admin_login` (`aid`,`uname`,`pwd`) VALUES 
 (1,'admin','admin123');
/*!40000 ALTER TABLE `admin_login` ENABLE KEYS */;


--
-- Definition of table `group_master`
--

DROP TABLE IF EXISTS `group_master`;
CREATE TABLE `group_master` (
  `gpid` int(10) unsigned NOT NULL auto_increment,
  `tid` int(10) unsigned NOT NULL,
  `eno1` varchar(45) NOT NULL,
  `eno2` varchar(45) default NULL,
  `eno3` varchar(45) default NULL,
  `eno4` varchar(45) default NULL,
  `date` varchar(45) default NULL,
  `ptitle` varchar(45) default NULL,
  PRIMARY KEY  (`gpid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group_master`
--

/*!40000 ALTER TABLE `group_master` DISABLE KEYS */;
INSERT INTO `group_master` (`gpid`,`tid`,`eno1`,`eno2`,`eno3`,`eno4`,`date`,`ptitle`) VALUES 
 (1,1,'0103CS183D09','0103CS183D07',NULL,NULL,'19/Jan/2020','Engg.'),
 (5,1,'0103CS183D01','0103CS183D02',NULL,NULL,'19/Jan/2020','nm'),
 (6,1,'0103CS183D03',NULL,NULL,NULL,'19/Jan/2020','as'),
 (7,1,'0103CS183D03',NULL,NULL,NULL,'19/Jan/2020','ada');
/*!40000 ALTER TABLE `group_master` ENABLE KEYS */;


--
-- Definition of table `guide`
--

DROP TABLE IF EXISTS `guide`;
CREATE TABLE `guide` (
  `gid` int(10) unsigned NOT NULL auto_increment,
  `tid` int(10) unsigned NOT NULL,
  `gname` varchar(45) NOT NULL,
  `pwd` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `mno` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  PRIMARY KEY  (`gid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `guide`
--

/*!40000 ALTER TABLE `guide` DISABLE KEYS */;
INSERT INTO `guide` (`gid`,`tid`,`gname`,`pwd`,`gender`,`mno`,`email`) VALUES 
 (1,1,'Rajesh','purnea123','Male','986876868','nk701531@gmail.com'),
 (2,2,'shriyanch','purnea123','Male','8798799879','gupta@gmail.com'),
 (3,3,'Aaksh','purnea123','Male','968745321','nitish@gmail.com'),
 (4,2,'Aman','purnea123','Male','9879866','aman@gmail.com');
/*!40000 ALTER TABLE `guide` ENABLE KEYS */;


--
-- Definition of table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE `student` (
  `eno` varchar(80) NOT NULL,
  `name` varchar(45) NOT NULL,
  `pwd` varchar(45) NOT NULL,
  `gender` varchar(45) NOT NULL,
  `section` varchar(45) NOT NULL,
  `sem` varchar(45) NOT NULL,
  `branch` varchar(45) NOT NULL,
  `mno` varchar(45) NOT NULL,
  PRIMARY KEY  (`eno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` (`eno`,`name`,`pwd`,`gender`,`section`,`sem`,`branch`,`mno`) VALUES 
 ('0103CS183D01','Akash ','purnea123','Male','C','5','CSE','78963254'),
 ('0103CS183D02','Priyanka','purnea123','Male','B','5','CSE','785432145');
/*!40000 ALTER TABLE `student` ENABLE KEYS */;


--
-- Definition of table `technology`
--

DROP TABLE IF EXISTS `technology`;
CREATE TABLE `technology` (
  `tid` int(10) unsigned NOT NULL auto_increment,
  `tname` varchar(45) NOT NULL,
  PRIMARY KEY  (`tid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `technology`
--

/*!40000 ALTER TABLE `technology` DISABLE KEYS */;
INSERT INTO `technology` (`tid`,`tname`) VALUES 
 (1,'java'),
 (2,'python'),
 (3,'c#');
/*!40000 ALTER TABLE `technology` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
